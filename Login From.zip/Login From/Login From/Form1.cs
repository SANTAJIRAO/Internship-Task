﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;


namespace WindowsFormsApp12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Username cannot be empty");
                return;
            }

            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("Password cannot be empty");
                return;
            }

            
            string cs = ConfigurationManager.ConnectionStrings["College_Login1"].ConnectionString;

            SqlConnection conn = new SqlConnection(cs);

            
            {
                string query = "SELECT COUNT(1) FROM College_Login1 WHERE User_Name=@username AND Password=@password";
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@username", textBox1.Text);
                    cmd.Parameters.AddWithValue("@password", textBox2.Text);

                    int count = Convert.ToInt32(cmd.ExecuteScalar());

                    if (count == 1)
                    {
                        MessageBox.Show("Login successful");


                     }
                    else
                    {
                        MessageBox.Show("Username or Password is incorrect");
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Username cannot be empty");
                return;
            }

            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("Password cannot be empty");
                return;
            }

            string cs = ConfigurationManager.ConnectionStrings["College_Login1"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(cs))
            {
                string query = "UPDATE College_Login1 SET Password=@newPassword WHERE User_Name=@username";
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@username", textBox1.Text);
                    cmd.Parameters.AddWithValue("@newPassword", textBox2.Text);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Password updated successfully");
                    }
                    else
                    {
                        MessageBox.Show("Username not found");
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Username cannot be empty");
                return;
            }

            string cs = ConfigurationManager.ConnectionStrings["College_Login1"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(cs))
            {
                string query = "DELETE FROM College_Login1 WHERE User_Name=@username";
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@username", textBox1.Text);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("User deleted successfully");
                    }
                    else
                    {
                        MessageBox.Show("Username not found");

                    }
                }
            }
        }

    }
}
