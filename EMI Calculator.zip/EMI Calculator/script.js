document.addEventListener('DOMContentLoaded', function() {
    const calculateBtn = document.getElementById('calculateBtn');
    const resetBtn = document.getElementById('resetBtn');
    const resultDiv = document.getElementById('result');

    calculateBtn.addEventListener('click', calculateEMI);
    resetBtn.addEventListener('click', resetForm);

    function calculateEMI() {
        const loanAmount = parseFloat(document.getElementById('loanAmount').value);
        const interestRate = parseFloat(document.getElementById('interestRate').value) / 100 / 12; // Monthly interest rate
        const loanTerm = parseInt(document.getElementById('loanTerm').value);

        if (isNaN(loanAmount) || isNaN(interestRate) || isNaN(loanTerm)) {
            resultDiv.textContent = 'Please enter valid numbers for all fields.';
            return;
        }

        const emi = (loanAmount * interestRate * Math.pow(1 + interestRate, loanTerm)) / (Math.pow(1 + interestRate, loanTerm) - 1);
        const totalAmount = emi * loanTerm;
        const totalInterest = totalAmount - loanAmount;

        resultDiv.innerHTML = `
            <p>EMI: ₹${emi.toFixed(2)}</p>
            <p>Total Amount: ₹${totalAmount.toFixed(2)}</p>
            <p>Total Interest: ₹${totalInterest.toFixed(2)}</p>
        `;
    }

    function resetForm() {
        document.getElementById('loanAmount').value = '';
        document.getElementById('interestRate').value = '';
        document.getElementById('loanTerm').value = '';
        resultDiv.textContent = '';
    }
});